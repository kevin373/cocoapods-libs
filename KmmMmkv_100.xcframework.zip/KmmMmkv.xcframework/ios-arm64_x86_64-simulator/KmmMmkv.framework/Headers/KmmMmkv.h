#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class KmmMmkvKotlinByteArray, KmmMmkvKotlinEnumCompanion, KmmMmkvKotlinEnum<E>, KmmMmkvMMKVLogLevel, KmmMmkvKotlinArray<T>, KmmMmkvMMKVMode, KmmMmkvMMKVImpl, NSDate, NSObject, KmmMmkvKotlinByteIterator;

@protocol KmmMmkvMMKV_KMP, KmmMmkvKotlinComparable, KmmMmkvKotlinIterator;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface KmmMmkvBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface KmmMmkvBase (KmmMmkvBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface KmmMmkvMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface KmmMmkvMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorKmmMmkvKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface KmmMmkvNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface KmmMmkvByte : KmmMmkvNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface KmmMmkvUByte : KmmMmkvNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface KmmMmkvShort : KmmMmkvNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface KmmMmkvUShort : KmmMmkvNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface KmmMmkvInt : KmmMmkvNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface KmmMmkvUInt : KmmMmkvNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface KmmMmkvLong : KmmMmkvNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface KmmMmkvULong : KmmMmkvNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface KmmMmkvFloat : KmmMmkvNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface KmmMmkvDouble : KmmMmkvNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface KmmMmkvBoolean : KmmMmkvNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("MMKV_KMP")))
@protocol KmmMmkvMMKV_KMP
@required
- (NSArray<NSString *> *)allKeys __attribute__((swift_name("allKeys()")));
- (void)async __attribute__((swift_name("async()")));
- (void)checkReSetCryptKeyKey:(NSString * _Nullable)key __attribute__((swift_name("checkReSetCryptKey(key:)")));
- (void)clearAll __attribute__((swift_name("clearAll()")));
- (void)clearMemoryCache __attribute__((swift_name("clearMemoryCache()")));
- (void)close __attribute__((swift_name("close()")));
- (BOOL)containsKeyKey:(NSString *)key __attribute__((swift_name("containsKey(key:)")));
- (NSString *)mmapID __attribute__((swift_name("mmapID()")));
- (void)removeValueForKeyKey:(NSString *)key __attribute__((swift_name("removeValueForKey(key:)")));
- (void)removeValuesForKeysKeys:(NSArray<NSString *> *)keys __attribute__((swift_name("removeValuesForKeys(keys:)")));
- (BOOL)setKey:(NSString *)key value:(BOOL)value __attribute__((swift_name("set(key:value:)")));
- (BOOL)setKey:(NSString *)key value_:(KmmMmkvKotlinByteArray *)value __attribute__((swift_name("set(key:value_:)")));
- (BOOL)setKey:(NSString *)key value__:(double)value __attribute__((swift_name("set(key:value__:)")));
- (BOOL)setKey:(NSString *)key value___:(float)value __attribute__((swift_name("set(key:value___:)")));
- (BOOL)setKey:(NSString *)key value____:(int32_t)value __attribute__((swift_name("set(key:value____:)")));
- (BOOL)setKey:(NSString *)key value_____:(int64_t)value __attribute__((swift_name("set(key:value_____:)")));
- (BOOL)setKey:(NSString *)key value______:(NSString *)value __attribute__((swift_name("set(key:value______:)")));
- (BOOL)setKey:(NSString *)key value_______:(uint32_t)value __attribute__((swift_name("set(key:value_______:)")));
- (BOOL)setKey:(NSString *)key value________:(uint64_t)value __attribute__((swift_name("set(key:value________:)")));
- (BOOL)setKey:(NSString *)key value_________:(NSSet<NSString *> * _Nullable)value __attribute__((swift_name("set(key:value_________:)")));
- (void)sync __attribute__((swift_name("sync()")));
- (BOOL)takeBooleanKey:(NSString *)key default:(BOOL)default_ __attribute__((swift_name("takeBoolean(key:default:)")));
- (KmmMmkvKotlinByteArray * _Nullable)takeByteArrayKey:(NSString *)key default:(KmmMmkvKotlinByteArray * _Nullable)default_ __attribute__((swift_name("takeByteArray(key:default:)")));
- (double)takeDoubleKey:(NSString *)key default:(double)default_ __attribute__((swift_name("takeDouble(key:default:)")));
- (float)takeFloatKey:(NSString *)key default:(float)default_ __attribute__((swift_name("takeFloat(key:default:)")));
- (int32_t)takeIntKey:(NSString *)key default:(int32_t)default_ __attribute__((swift_name("takeInt(key:default:)")));
- (int64_t)takeLongKey:(NSString *)key default:(int64_t)default_ __attribute__((swift_name("takeLong(key:default:)")));
- (NSString *)takeStringKey:(NSString *)key default:(NSString *)default_ __attribute__((swift_name("takeString(key:default:)")));
- (NSSet<NSString *> * _Nullable)takeStringSetKey:(NSString *)key default:(NSSet<NSString *> * _Nullable)default_ __attribute__((swift_name("takeStringSet(key:default:)")));
- (uint32_t)takeUIntKey:(NSString *)key default:(uint32_t)default_ __attribute__((swift_name("takeUInt(key:default:)")));
- (uint64_t)takeULongKey:(NSString *)key default:(uint64_t)default_ __attribute__((swift_name("takeULong(key:default:)")));
- (void)trim __attribute__((swift_name("trim()")));
@property (readonly) int64_t actualSize __attribute__((swift_name("actualSize")));
@property (readonly) int64_t count __attribute__((swift_name("count")));
@property (readonly) int64_t totalSize __attribute__((swift_name("totalSize")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MMKVImpl")))
@interface KmmMmkvMMKVImpl : KmmMmkvBase <KmmMmkvMMKV_KMP>
- (NSArray<NSString *> *)allKeys __attribute__((swift_name("allKeys()")));
- (void)async __attribute__((swift_name("async()")));
- (void)checkReSetCryptKeyKey:(NSString * _Nullable)key __attribute__((swift_name("checkReSetCryptKey(key:)")));
- (void)clearAll __attribute__((swift_name("clearAll()")));
- (void)clearMemoryCache __attribute__((swift_name("clearMemoryCache()")));
- (void)close __attribute__((swift_name("close()")));
- (BOOL)containsKeyKey:(NSString *)key __attribute__((swift_name("containsKey(key:)")));
- (NSString *)mmapID __attribute__((swift_name("mmapID()")));
- (void)removeValueForKeyKey:(NSString *)key __attribute__((swift_name("removeValueForKey(key:)")));
- (void)removeValuesForKeysKeys:(NSArray<NSString *> *)keys __attribute__((swift_name("removeValuesForKeys(keys:)")));
- (BOOL)setKey:(NSString *)key value:(BOOL)value __attribute__((swift_name("set(key:value:)")));
- (BOOL)setKey:(NSString *)key value_:(KmmMmkvKotlinByteArray *)value __attribute__((swift_name("set(key:value_:)")));
- (BOOL)setKey:(NSString *)key value__:(double)value __attribute__((swift_name("set(key:value__:)")));
- (BOOL)setKey:(NSString *)key value___:(float)value __attribute__((swift_name("set(key:value___:)")));
- (BOOL)setKey:(NSString *)key value____:(int32_t)value __attribute__((swift_name("set(key:value____:)")));
- (BOOL)setKey:(NSString *)key value_____:(int64_t)value __attribute__((swift_name("set(key:value_____:)")));
- (BOOL)setKey:(NSString *)key value______:(NSString *)value __attribute__((swift_name("set(key:value______:)")));
- (BOOL)setKey:(NSString *)key value_______:(uint32_t)value __attribute__((swift_name("set(key:value_______:)")));
- (BOOL)setKey:(NSString *)key value________:(uint64_t)value __attribute__((swift_name("set(key:value________:)")));
- (BOOL)setKey:(NSString *)key value_________:(NSSet<NSString *> * _Nullable)value __attribute__((swift_name("set(key:value_________:)")));
- (void)sync __attribute__((swift_name("sync()")));
- (BOOL)takeBooleanKey:(NSString *)key default:(BOOL)default_ __attribute__((swift_name("takeBoolean(key:default:)")));
- (KmmMmkvKotlinByteArray * _Nullable)takeByteArrayKey:(NSString *)key default:(KmmMmkvKotlinByteArray * _Nullable)default_ __attribute__((swift_name("takeByteArray(key:default:)")));
- (double)takeDoubleKey:(NSString *)key default:(double)default_ __attribute__((swift_name("takeDouble(key:default:)")));
- (float)takeFloatKey:(NSString *)key default:(float)default_ __attribute__((swift_name("takeFloat(key:default:)")));
- (int32_t)takeIntKey:(NSString *)key default:(int32_t)default_ __attribute__((swift_name("takeInt(key:default:)")));
- (int64_t)takeLongKey:(NSString *)key default:(int64_t)default_ __attribute__((swift_name("takeLong(key:default:)")));
- (NSString *)takeStringKey:(NSString *)key default:(NSString *)default_ __attribute__((swift_name("takeString(key:default:)")));
- (NSSet<NSString *> * _Nullable)takeStringSetKey:(NSString *)key default:(NSSet<NSString *> * _Nullable)default_ __attribute__((swift_name("takeStringSet(key:default:)")));
- (uint32_t)takeUIntKey:(NSString *)key default:(uint32_t)default_ __attribute__((swift_name("takeUInt(key:default:)")));
- (uint64_t)takeULongKey:(NSString *)key default:(uint64_t)default_ __attribute__((swift_name("takeULong(key:default:)")));
- (void)trim __attribute__((swift_name("trim()")));
@property (readonly) int64_t actualSize __attribute__((swift_name("actualSize")));
@property (readonly) int64_t count __attribute__((swift_name("count")));
@property (readonly) int64_t totalSize __attribute__((swift_name("totalSize")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol KmmMmkvKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface KmmMmkvKotlinEnum<E> : KmmMmkvBase <KmmMmkvKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) KmmMmkvKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MMKVLogLevel")))
@interface KmmMmkvMMKVLogLevel : KmmMmkvKotlinEnum<KmmMmkvMMKVLogLevel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmmMmkvMMKVLogLevel *leveldebug __attribute__((swift_name("leveldebug")));
@property (class, readonly) KmmMmkvMMKVLogLevel *levelinfo __attribute__((swift_name("levelinfo")));
@property (class, readonly) KmmMmkvMMKVLogLevel *levelwarning __attribute__((swift_name("levelwarning")));
@property (class, readonly) KmmMmkvMMKVLogLevel *levelerror __attribute__((swift_name("levelerror")));
@property (class, readonly) KmmMmkvMMKVLogLevel *levelnone __attribute__((swift_name("levelnone")));
+ (KmmMmkvKotlinArray<KmmMmkvMMKVLogLevel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<KmmMmkvMMKVLogLevel *> *entries __attribute__((swift_name("entries")));
@property (readonly) uint64_t rawValue __attribute__((swift_name("rawValue")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MMKVMode")))
@interface KmmMmkvMMKVMode : KmmMmkvKotlinEnum<KmmMmkvMMKVMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmmMmkvMMKVMode *singleProcess __attribute__((swift_name("singleProcess")));
@property (class, readonly) KmmMmkvMMKVMode *multiProcess __attribute__((swift_name("multiProcess")));
+ (KmmMmkvKotlinArray<KmmMmkvMMKVMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<KmmMmkvMMKVMode *> *entries __attribute__((swift_name("entries")));
@property (readonly) uint64_t rawValue __attribute__((swift_name("rawValue")));
@end

@interface KmmMmkvMMKVImpl (Extensions)
- (BOOL)setKey:(NSString *)key value__________:(NSDate *)value __attribute__((swift_name("set(key:value__________:)")));
- (BOOL)setKey:(NSString *)key value___________:(NSObject * _Nullable)value __attribute__((swift_name("set(key:value___________:)")));
- (NSDate * _Nullable)takeNSDateKey:(NSString *)key default:(NSDate * _Nullable)default_ __attribute__((swift_name("takeNSDate(key:default:)")));
- (id _Nullable)takeObjectKey:(NSString *)key cls:(Class)cls __attribute__((swift_name("takeObject(key:cls:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UtilIosKt")))
@interface KmmMmkvUtilIosKt : KmmMmkvBase
+ (BOOL)backupOneToDirectoryMmapID:(NSString *)mmapID dstDir:(NSString *)dstDir rootPath:(NSString * _Nullable)rootPath __attribute__((swift_name("backupOneToDirectory(mmapID:dstDir:rootPath:)")));
+ (int64_t)pageSize __attribute__((swift_name("pageSize()")));
+ (void)setLogLevelLogLevel:(KmmMmkvMMKVLogLevel *)logLevel __attribute__((swift_name("setLogLevel(logLevel:)")));
+ (void)unregisterHandler __attribute__((swift_name("unregisterHandler()")));
+ (NSString *)version __attribute__((swift_name("version()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreatorIosKt")))
@interface KmmMmkvCreatorIosKt : KmmMmkvBase
+ (id<KmmMmkvMMKV_KMP>)defaultMMKV __attribute__((swift_name("defaultMMKV()")));
+ (id<KmmMmkvMMKV_KMP>)defaultMMKVCryptKey:(NSString *)cryptKey __attribute__((swift_name("defaultMMKV(cryptKey:)")));
+ (id<KmmMmkvMMKV_KMP>)mmkvWithIDMmapId:(NSString *)mmapId mode:(KmmMmkvMMKVMode *)mode cryptKey:(NSString * _Nullable)cryptKey rootPath:(NSString * _Nullable)rootPath __attribute__((swift_name("mmkvWithID(mmapId:mode:cryptKey:rootPath:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InitializeIosKt")))
@interface KmmMmkvInitializeIosKt : KmmMmkvBase
+ (void)initialize __attribute__((swift_name("initialize()")));
+ (NSString *)initializeRootDir:(NSString *)rootDir __attribute__((swift_name("initialize(rootDir:)")));
+ (NSString *)initializeRootDir:(NSString *)rootDir logLevel:(KmmMmkvMMKVLogLevel *)logLevel __attribute__((swift_name("initialize(rootDir:logLevel:)")));
+ (NSString *)initializeRootDir:(NSString *)rootDir groupDir:(NSString *)groupDir logLevel:(KmmMmkvMMKVLogLevel *)logLevel __attribute__((swift_name("initialize(rootDir:groupDir:logLevel:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExtensionKt")))
@interface KmmMmkvExtensionKt : KmmMmkvBase
+ (id _Nullable)withOpen:(id<KmmMmkvMMKV_KMP>)receiver block:(id _Nullable (^)(id<KmmMmkvMMKV_KMP>))block __attribute__((swift_name("withOpen(_:block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface KmmMmkvKotlinByteArray : KmmMmkvBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(KmmMmkvByte *(^)(KmmMmkvInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (KmmMmkvKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface KmmMmkvKotlinEnumCompanion : KmmMmkvBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) KmmMmkvKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface KmmMmkvKotlinArray<T> : KmmMmkvBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(KmmMmkvInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<KmmMmkvKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol KmmMmkvKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface KmmMmkvKotlinByteIterator : KmmMmkvBase <KmmMmkvKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (KmmMmkvByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
